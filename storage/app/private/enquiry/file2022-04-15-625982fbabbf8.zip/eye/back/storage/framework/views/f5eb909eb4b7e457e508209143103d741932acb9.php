<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>report</title>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- osama edit -->
    <style>
        body {
            text-align: right;
        }

        * {
            box-sizing: border-box;
        }

        div {
            -webkit-print-color-adjust: exact;

        }

        .contains {
            width: 595px;
            background-color: #FFFFFF;
            margin: 0px auto;
            border: 1px solid #FFFFFF;
            padding: 5px;
        }

        .page {
            width: 100%;
            min-height: 942px;
            overflow: hidden;
            position: relative;
            margin: auto;

        }

        .bglogo {
            background: url('<?php echo e(asset('images/icon-back.png')); ?>') no-repeat;
            background-size: 700px 960px;
            margin: auto;
        }

        .pageintron {
            width: 100%;
            min-height: 840px;
            overflow: hidden;
            position: relative;
        }

        .intro {
            background: url('<?php echo e(asset('documents/projects/'.$project->image)); ?>') no-repeat left top;
            margin: auto;
            background-size: cover;
        }

        .intro-footer {
            position: absolute;
            bottom: 0px;
            background-color: #333333;
            width: 100%;
            text-align: left;
        }

        .intro-title {
            position: absolute;
            text-align: center;
            color: #FFFFFF;
            right: 10px;
            bottom: 230px;
        }

        .intro-decouration {
            position: absolute;
            bottom: 101px;
            width: 100%;
            text-align: left;
        }

        .intro-title span {
            display: block;
            font-size: 18px;
        }

        .intro-title h2 {
            margin: 10px 0px;
        }

        h1 {
            color: #dd858c;
            font-size: 18px;
            text-decoration: underline;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        table.info {
            width: 100%;
            border-collapse: collapse;
            direction: rtl;

        }

        table.info td {
            border: 3px solid black;
            font-size: 16px;
            padding: 10px;
            width: 25%;
            height: 20px;

        }

        table.info td.special {
            background-color: #ECF2EF;
        }

        @media  print {
            footer {
                position: fixed;
                bottom: 0;
            }

            .contains {
                width: 100%;
            }

            .pageintron {
                size: letter;
                width: 100%;
                min-height: 940px;
                overflow: hidden;
                position: relative;
            }

            .page {
                size: letter;
                width: 100%;
                min-height: 980px;
                overflow: hidden;
                position: relative;

            }

            .intro-title {
                position: absolute;
                text-align: center;
                color: #FFFFFF;
                right: 20px;
                bottom: 285px;
                font-size: 20px;
            }

            .bglogo {
                background: url('<?php echo e(asset('images/icon-back.png')); ?>') no-repeat;
                background-size: 700px 975px;
                margin: auto;
            }

            .pagespiceal {
                size: letter;
                width: 100%;
                min-height: 2900px;
                overflow: hidden;
                position: relative;
            }

            .intro-title {
                background-color: #333333;
                -webkit-print-color-adjust: exact;
            }

            .print {
                display: none;
            }

        }

        table {
            max-width: 700px;

            border: 1px solid #000000;
            font-size: 16px;
            text-align: right;
            border-collapse: collapse;
        }

        td {
            border: 1px solid #000000;

            text-align: right;
            padding: 2px;
            vertical-align: center;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .table-insider {
            text-align: right;
            width: 100%;
            direction: rtl;
            border-collapse: collapse;
            border: 1px solid #000000;
            font-size: 20px;
            margin-top: 20px;

        }

        .table-insider td.special {
            background-color: #ECF2EF;
        }

        .table-insider td {
            border: 1px solid #000000;
            padding: 5px 10px;
            height: 40px;
        }

        .img-container {
            width: 100%;
        }

        .img-container:after {
            display: block;
            clear: both;
            content: '';
        }

        .img-container img {
            width: 695px;
            height: 435px;

            display: inline;
        }

        .file-container {
            width: 100%;
        }

        .file-container:after {
            display: block;
            clear: both;
            content: '';
        }

        .file-container img {
            width: 100%;
            height: 100%;
            max-height: 900px;
            float: none;
            /*margin: auto;*/
            display: inline;
        }

        .additional-insider {
            direction: rtl;
        }

        .additional-insider-1 {

        }
    </style>
</head>
<body>
<button class="print" type="button" onclick="window.print();">
    Print PDF
</button>

<div class="contains" id="printPdf">
    <div class="pageintron intro">
        <div class="intro-decouration">
            <div class="intro-decouration-img">
                <div class="intro-title">
                    <h2>مشروع: <?php echo e($project->name); ?></h2>
                    <span>التقرير الاسبوعي</span>
                    <span>من <?php echo e($report->starting_date); ?> الي <?php echo e($report->ending_date); ?></span>
                </div>
                <img src="<?php echo e(asset('images/intro_decouration.png')); ?>" style="width: 100%;">
            </div>

        </div>
        <div class="intro-footer">
            <div class="logo-footer">
                <img src="<?php echo e(asset('images/logo-complete.png')); ?>" style="width: 100%;">
            </div>
        </div>

    </div>

    <div class="page bglogo">
        <h1>:. اولا التعريف بالمشروع</h1>
        <table class="info" border="1">
            <tr>
                <td class="special">اسم المشروع</td>
                <td><?php echo e($project->name); ?></td>
                <td class="special">رقم المنافسة</td>
                <td></td>
            </tr>
            <tr>
                <td class="special">اسم المالك</td>
                <td><?php echo e($project->owner->name); ?></td>
                <td class="special">اسم المقاول</td>
                <td><?php echo e($project->contractor->name); ?></td>
            </tr>
            <tr>
                <td class="special">قيمة عقد المشروع بعد اوامر الغيير</td>
                <td><?php echo e(number_format($project->contract_value, 2)); ?> ريال</td>
                <td class="special">موقع المشروع</td>
                <td><?php echo e($project->city); ?></td>
            </tr>
            <tr>
                <td class="special">تاريخ تسليم الموقع</td>
                <td><?php echo e($project->contract_ending); ?></td>
                <td class="special">تاريخ بداية العقد</td>
                <td><?php echo e($project->contract_starting); ?></td>
            </tr>
            <tr>
                <td class="special">مدة العقد</td>
                <td><?php echo e(dateDiff($project->contract_starting,$project->contract_ending)->days); ?> يوم</td>
                <td class="special">المدة المنقضية</td>
                <td><?php echo e(dateDiff($project->contract_starting,date('Y-m-d'))->days); ?> يوم</td>
            </tr>
            <tr>
                <td class="special">نسبة الانجاز المالية</td>
                <td><?php echo e($report->financial_achievement_ratio); ?>%</td>
                <td class="special">نسبة الانجاز الفعلية</td>
                <td><?php echo e($report->actual_completion_rate); ?>%</td>
            </tr>
            <tr>
                <td class="special">عدد المباني</td>
                <td><?php echo e($report->project->quantity->buildings_num); ?></td>
                <td class="special">نسبة الانجازالمطلوبه</td>
                <td><?php echo e($report->percentage_achievement_required); ?>%</td>
            </tr>
            <tr>
                <td class="special">نطاق الاعمال</td>
                <td colspan="3" class="special"><?php echo e($project->description); ?></td>
            </tr>
        </table>


        
        
        
        
        
        
        
        
        
        
        
        
        


        
        <?php if(count($report->project->consultantEngineers)>0): ?>

            <h1>الهيكل التنظيمي لجهاز الاشراف</h1>
            <table class="table-insider">
                <tr>
                    <td class="special">الاسم</td>
                    <td class="special">المهنة</td>
                </tr>
                <?php $__currentLoopData = $report->project->consultantEngineers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultantEngineer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($consultantEngineer->engineer->name); ?></td>
                        <td><?php echo e(Lang::get('terms.'.$consultantEngineer->consultant_engineer_position)); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        <?php endif; ?>
    </div>
    <?php if(count($report->contractorTeam)>0): ?>
        <div class="page bglogo">
            <h1>الهيكل التنظيمي لجهاز المقاول</h1>
            <table class="table-insider">
                <tr>
                    <td class="special">المهنة</td>
                    <td class="special">العدد</td>
                    <td class="special">الاسم</td>
                </tr>
                <?php $__currentLoopData = $report->contractorTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractorTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contractorTeam->position); ?></td>
                        <td><?php echo e($contractorTeam->number); ?></td>
                        <td><?php echo e($contractorTeam->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
    <?php endif; ?>
    <?php if(count($report->tools)>0): ?>
        <div class="page bglogo">
            <h1>معدات المقاول وأدوات بالموقع </h1>
            <table class="table-insider">
                <tr>
                    <td class="special">المعدة</td>
                    <td class="special">العدد</td>
                    <td class="special">ملاحظات</td>
                </tr>
                <?php $__currentLoopData = $report->tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tool->tool); ?></td>
                        <td><?php echo e($tool->number); ?></td>
                        <td><?php echo e($tool->note); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php endif; ?>
    <?php if(isset($report->schedule)): ?>
        <div class="page">
            <h1>البرنامج الزمنى</h1>

            <div class="additional-insider">
                <img src="<?php echo e(asset('documents/projects/w_report/'.$report->schedule)); ?>"
                     style="width: 100%; height: 100%">
            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->report_status ) ): ?>
        <div class="page bglogo">
            <h1>بيان الحالة</h1>

            <div class="additional-insider">
                <?php echo $report->additionalInfo->report_status; ?>

            </div>
        </div>
        <div class="page bglogo">
            <?php endif; ?>
            <?php if(isset($report->additionalInfo->working_rate)): ?>
                <h1>معدل سير العمل</h1>

                <div class="additional-insider">
                    <?php echo $report->additionalInfo->working_rate; ?>

                </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->completion_Schedule)): ?>
        <div class="page bglogo">
            <h1>جدول نسب الانجاز</h1>

            <div class="additional-insider" style="direction: rtl;">
                <?php echo $report->additionalInfo->completion_Schedule; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->done_working)): ?>
        <div class="pagespiceal">
            <h1>بيان الاعمال المنفذه بالمشروع </h1>

            <div class="additional-insider-1">
                <?php echo $report->additionalInfo->done_working; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->working_next_month)): ?>
        <div class="page bglogo">
            <h1>وصف الاعمال المتوقع انجازها خلال الشهر القادم </h1>

            <div class="additional-insider">
                <?php echo $report->additionalInfo->working_next_month; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->consultant_note)): ?>
        <div class="page">
            <h1>ملاحظات الاستشارى على الاعمال بالموقع </h1>

            <div class="additional-insider">
                <?php echo $report->additionalInfo->consultant_note; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->contractor_required)): ?>
        <div class="page bglogo">
            <h1>المطلوب من المقاول </h1>

            <div class="additional-insider">
                <?php echo $report->additionalInfo->contractor_required; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(isset($report->additionalInfo->owner_required)): ?>
        <div class="page bglogo">
            <h1>الالمطلوب من المالك </h1>

            <div class="additional-insider">
                <?php echo $report->additionalInfo->owner_required; ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(count($report->tests)>0): ?>
        <div class="page">
            <h1>نتائج الاختبارات </h1>

            <div class="additional-insider">
                <?php $__currentLoopData = $report->tests->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="file-container">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('documents/projects/tests/'.$test->test->document)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(count($report->requests)>0 || count($report->submittals)>0): ?>
        <div class="page">
            <h1>المخاطبات ومحاضر الاجتماعات </h1>
            <div class="additional-insider">


                <?php $__currentLoopData = $report->requests->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="file-container">

                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('documents/projects/requests/'.$requests->request->document)); ?>">
                            <h1></h1>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $report->submittals->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="file-container">

                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submittals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h1></h1>
                            <img src="<?php echo e(asset('documents/projects/submittals/'.$submittals->submittal->document)); ?>">

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
        </br>
    <?php endif; ?>
    <?php if(count($report->files)>0): ?>
        <div class="page">
            <h1>الصور الفوتوغرافيه</h1>
            <div class="additional-insider">
                <?php $__currentLoopData = $report->files->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="img-container">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img src="<?php echo e(asset('documents/projects/files/'.$file->file->document)); ?>"> <span
                                        style="display: block; text-align: center; font-weight: bold;"><?php echo e($file->file->description); ?></span>
                            </div>
                            </br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </br>
                    <div style="height: 5px"></div>
            </div>
        </div>
        </br>
    <?php endif; ?>
    <?php if(!is_null($report->additionalInfo)): ?>
        <div class="page bglogo">
            <h1>توصيات الاستشاري </h1>
            <div class="additional-insider">
                <span style="display: block; text-align: right; font-size:16px;"> <?php echo $report->additionalInfo->consultant_recommendations; ?> </span>
            </div>


            <div class="additional-insider">
                <span style="font-weight: bold; text-align: right;"><?php echo $report->text; ?></span>
                <span style="font-weight: bold; text-align:left ; margin-left: 0px;">مدير المشروع </span>

            </div>
        </div>
    <?php endif; ?>
</div>
</div>

</body>
</html>