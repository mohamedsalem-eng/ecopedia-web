<div class="row">
    <?php $__currentLoopData = $submittals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submittal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(getFileType($submittal->document)['type']=="image"): ?>
            <div class="col-md-3 item-list">
                <img src="<?php echo e(asset('documents/projects/submittals/'.$submittal->document)); ?>">
                <input type="checkbox" name="project_submittal[][submittal_id]" value="<?php echo e($submittal->id); ?>">
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
