
<?php $__env->startSection('container'); ?>
    test
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts.Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>