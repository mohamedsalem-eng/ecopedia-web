<?php $__currentLoopData = $files->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12  file-box">
                <div class="file"><a href="<?php echo e(asset('documents/projects/files/'.$file->document)); ?>" target="_blank">
                        <div class="icon">
                            <?php
                            $fileType = getFileType($file->document);
                            ?>
                            <i class="fas <?php echo e($fileType['icon']); ?> <?php echo e($fileType['color']); ?>"></i>
                        </div>
                        <div class="file-name"> <?php echo e($file->description); ?> <br>
                            <span>Added: <?php echo e(date('M d,Y',strtotime($file->created_at))); ?></span></div>
                    </a></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>