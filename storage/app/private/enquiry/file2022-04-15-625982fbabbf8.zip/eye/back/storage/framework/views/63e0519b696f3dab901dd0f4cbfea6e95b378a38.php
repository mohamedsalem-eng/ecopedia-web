<div class="row">
    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(getFileType($request->document)['type']=="image"): ?>
            <div class="col-md-3 item-list">
                <img src="<?php echo e(asset('documents/projects/requests/'.$request->document)); ?>">
                <input type="checkbox" name="project_request[][request_id]" value="<?php echo e($request->id); ?>">
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
