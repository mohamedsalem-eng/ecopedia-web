<?php $__currentLoopData = $timeLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="15" style="background-color: <?php echo e($colors['color']); ?>; color: #ffffff;">
            <?php echo $timeLine->getModel()->nameWithAllParents(' <i class="fas fa-angle-left"></i> '); ?>

        </td>
    </tr>
    <?php $__currentLoopData = $timeLine->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-ajax--url="<?php echo e(route('schedulesNew.update',['schedule'=>$schedule->id])); ?>"
            data-tokens="<?php echo e(csrf_token()); ?>" data-project-id="<?php echo e($project->id); ?>">
            <?php
            $resolver = new \App\Http\Controllers\Admin\ScheduleResolver($schedule);
            $planed_st_date = isset($schedule->planed_starting_date)
                ? \Carbon\Carbon::parse($schedule->planed_starting_date)->format('d-M-y') : null;
            ?>
            <td class="en-label"><?php echo e(ucfirst($schedule->activity_id)); ?></td>
            <td class="en-label"><?php echo $schedule->related_to?ucfirst($schedule->related_to):"-"; ?></td>
            <td><?php echo e(Lang::get('terms.'.$schedule->sort)); ?></td>
            <td><?php echo e($schedule->activity_name); ?></td>
            <td><?php echo e($schedule->default_duration); ?></td>
            <td class="en-label"><?php echo $resolver->getPlanedStDate()?$resolver->getPlanedStDate():"---"; ?></td>
            <td class="en-label"><?php echo $resolver->getPlanedEndDate()?$resolver->getPlanedEndDate():"---"; ?></td>
            <td class="en-label update-on_click">
                <input name="actual_starting_date" id="date_picker"
                       value="<?php echo e($resolver->getActualStDate()); ?>" disabled>

            </td>
            <td class="en-label update-on_click">
                <input name="actual_ending_date" id="date_picker"
                       value="<?php echo e($resolver->getActualEndDate()); ?>" disabled>
            </td>
            <td>
                
                       
                <select name="status" class="form-control select2-single ajax-selection" dir="rtl">
                    <option value="">جاري</option>
                    <?php for($i=0;$i<=100;$i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo $i==$schedule->status?"selected":null; ?>><?php echo e($resolver->getStatusName($i)); ?></option>
                    <?php endfor; ?>
                </select>
            </td>
            <td>
                <div class="input-container">
                    <input class="ajax-input" name="status_reason" value="<?php echo e($schedule->status_reason); ?>" disabled>
                </div>
            </td>
            <td>
                <div class="input-container">
                    <input class="ajax-input" name="note" value="<?php echo e($schedule->note); ?>" disabled>
                </div>
            </td>
            <td class="en-label"><?php echo $resolver->getCompletionPercentage()?$resolver->getCompletionPercentage()."%":"---"; ?></td>
            <td class="en-label"><?php echo $resolver->getDelayPercentage()?$resolver->getDelayPercentage()."%":"---"; ?></td>
            <td class="en-label"><?php echo !is_null($resolver->getDelayDuration())?$resolver->getDelayDuration():"---"; ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo timeLinesSons($timeLine,$project,$colors['child']); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>