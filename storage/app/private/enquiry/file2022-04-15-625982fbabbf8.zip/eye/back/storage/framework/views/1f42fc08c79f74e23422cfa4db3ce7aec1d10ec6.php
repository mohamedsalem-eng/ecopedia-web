<table id="pro_list" class="table table-hover display  pb-30">
    <thead>
    <tr>
        <th>م</th>
        <th>الرقم</th>
        <th>البند</th>
        <th>التاريخ</th>
        <th>النوع</th>
        <th>التصنيف</th>
        <th>الوصف</th>
        <th>الملف</th>
    </tr>
    </thead>
    <tfoot>
    <tr>
        <th>م</th>
        <th>الرقم</th>
        <th>البند</th>
        <th>التاريخ</th>
        <th>النوع</th>
        <th>التصنيف</th>
        <th>الوصف</th>
        <th>الملف</th>
    </tr>
    </tfoot>
    <tbody>
    <?php $arrangement = 1; ?>
    <?php $__currentLoopData = $submittals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submittal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($arrangement); ?></td>
            <td><?php echo e($submittal->number); ?></td>
            <td><?php echo e($submittal->related_item); ?></td>
            <td><?php echo e(date('d-m-Y',strtotime($submittal->date))); ?></td>
            <td><?php echo e(Lang::get('terms.'.$submittal->sort)); ?></td>
            <td><?php echo e(Lang::get('terms.'.$submittal->category)); ?></td>
            <td><?php echo e($submittal->description); ?></td>
            <td><a href="<?php echo e(asset('documents/projects/submittals/'.$submittal->document)); ?>">
                    <i class="fas fa-download"></i>
                </a></td>
        </tr>
        <?php $arrangement++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>