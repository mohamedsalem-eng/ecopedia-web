<div id="time_table_tab" class="tab-pane fade" role="tabpanel">
    <?php if(in_array(auth()->user()->permission->contractorPermissions->schedule,[4,5,6,7]) || auth()->guard('web')->check()): ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default card-view">
                    <?php if(in_array(auth()->user()->permission->contractorPermissions->schedule,[7]) || auth()->guard('web')->check()): ?>
                        <div class="modal fade" id="add_new_Test_Paper_model" tabindex="-1" role="dialog"
                             aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h5 class="modal-title" id="">انشاء جدول ذمني</h5>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-lg-12 col-sm-12">
                                                <div class="panel panel-default card-view">
                                                    <div class="panel-wrapper collapse in">
                                                        <div class="panel-body">

                                                            <div class="tab-struct custom-tab-2 mt-10">
                                                                <div class="tab-content" id="myTabContent_15">
                                                                    <div id="Reciving_request_tab"
                                                                         class="tab-pane fade active in"
                                                                         role="tabpanel">
                                                                        <form action="<?php echo e(route('time-line-items.store')); ?>"
                                                                              method="post"
                                                                              enctype="multipart/form-data">
                                                                            <input type="hidden" name="project_id"
                                                                                   value="<?php echo e($project->id); ?>">
                                                                            <?php echo e(csrf_field()); ?>

                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>عنوان الجدول
                                                                                            الزمني</label>
                                                                                        <select name="time_line_id"
                                                                                                class="form-control">
                                                                                            <option value="">اختار
                                                                                                عنوان
                                                                                            </option>
                                                                                            <?php $__currentLoopData = $project->timeLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <option value="<?php echo e($timeLine->id); ?>"><?php echo e($timeLine->nameWithAllParents()); ?></option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>الاسم</label>
                                                                                        <input class="form-control"
                                                                                               name="activity_name">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Original</label>
                                                                                        <input class="form-control"
                                                                                               name="original">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Activity #ID</label>
                                                                                        <input class="form-control"
                                                                                               name="activity_id">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label for="message-text"
                                                                                               class="control-label mb-10">تاريخ
                                                                                            البداية</label>
                                                                                        <input type="date"
                                                                                               name="starting_date"
                                                                                               class="form-control">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label for="message-text"
                                                                                               class="control-label mb-10">تاريخ
                                                                                            النهاية</label>
                                                                                        <input type="date"
                                                                                               name="ending_date"
                                                                                               class="form-control">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <div class="modal-footer">
                                                                                    <input type="submit" value="حفظ"
                                                                                           class="btn btn-success btn-rounded btn-block">
                                                                                </div>

                                                                            </div>
                                                                        </form>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn-success btn-rounded btn-block btn-anim" data-toggle="modal"
                                    data-target="#add_new_Test_Paper_model" data-whatever="@">
                                <i class="fa fa-pencil"></i><span class="btn-text">انشاء جدول ذمني</span></button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        
                        <table class="table table-bordered main-table">
                            <thead>
                            <tr>
                                <th>Activity ID</th>
                                <th>Activity Name</th>
                                <th>Original</th>
                                <th>Start</th>
                                <th>Finish</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $timeLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2"><?php echo e($timeLine->name); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php $__currentLoopData = $timeLine->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->activity_id); ?></td>
                                        <td><?php echo e($item->activity_name); ?>م</td>
                                        <td><?php echo e($item->original); ?></td>
                                        <td><?php echo e($item->starting_date); ?></td>
                                        <td><?php echo e($item->ending_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo timeLinesChilds($timeLine); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-12">
                <h5 class="text-center text-danger"><i class="fas fa-exclamation-triangle"></i> غير مسموح لك بالدخول علي
                    هذه البيانات</h5>
            </div>
        </div>
    <?php endif; ?>

</div>