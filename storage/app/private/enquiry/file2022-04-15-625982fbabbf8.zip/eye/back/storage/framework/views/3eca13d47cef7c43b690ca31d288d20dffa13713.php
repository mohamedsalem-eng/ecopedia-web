<div class="row">
    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(getFileType($file->document)['type']=="image"): ?>
            <div class="col-md-3 item-list">
                <img src="<?php echo e(asset('documents/projects/files/'.$file->document)); ?>">
                <input type="checkbox" name="project_files[][file_id]" value="<?php echo e($file->id); ?>">
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
