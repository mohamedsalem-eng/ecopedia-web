<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project_test_sort extends Model
{
    protected $fillable=[
      'name','related_to'
    ];
}
