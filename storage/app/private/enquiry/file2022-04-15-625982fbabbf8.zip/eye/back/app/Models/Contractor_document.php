<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Contractor_document extends Model
{
    protected $fillable=['document_type','document_file'];
}
