<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Eng_role extends Model
{
    protected $fillable=['engineer_type_id','add','edit','delete'];
}
