<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Engineer_detail extends Model
{
    protected $fillable=[
        'engineer_id','phone','phone2','type'
    ];
}
