<?
header("Location: http://www.iconeng.sa/eye/public/"); /* Redirect browser */
exit();
?>