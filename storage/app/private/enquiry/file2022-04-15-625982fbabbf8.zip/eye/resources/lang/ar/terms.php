<?php
return [
    'sample approval' => 'اعتماد عينه',
    'supplier approval' => 'اعتماد مخططات الورشه',
    'shop drawing approval' => 'اعتماد موردين',
    'subcontractor approval' => 'اعتماد مقاول باطن',
    'structural' => 'انشائي',
    'architectural' => 'معماري',
    'electrically' => 'كهرباء',
    'mechanics' => 'ميكانيكا',
    'general' => 'موقع عام',
    'other' => 'اخري',
    'location' => 'موقع',
    'lap' => 'مختبر',
    'manager'=>'مدير المشروع',
    'architect'=>'مهندس مدني',
];