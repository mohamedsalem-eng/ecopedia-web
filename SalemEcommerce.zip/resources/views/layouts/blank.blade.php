<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <title>
        @yield('title')
    </title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <!-- Viewport-->
    <meta name="_token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="apple-touch-icon" sizes="180x180" href="">
    <link rel="icon" type="image/png" sizes="32x32" href="">
    <link rel="icon" type="image/png" sizes="16x16" href="">
    <link rel="stylesheet" href="{{ asset('assets/back-end') }}/css/toastr.css" />
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="{{ asset('assets/front-end') }}/css/theme.min.css">
    <link rel="stylesheet" media="screen" href="{{ asset('assets/front-end') }}/css/slick.css">
    <link rel="stylesheet" href="{{ asset('assets/back-end') }}/css/toastr.css" />
    <link rel="stylesheet" href="{{ asset('assets/front-end') }}/css/master.css" />
</head>
<!-- Body-->

<body class="toolbar-enabled">

    {{-- loader --}}
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="loading" style="display: none;">
                    <div style="position: fixed;z-index: 9999; left: 40%;top: 37% ;width: 100%">
                        <img width="200" src="{{ asset('assets/front-end/img/loader.gif') }}">
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- loader --}}

    <!-- Page Content-->
    @yield('content')

    <!-- Back To Top Button-->
    <a class="btn-scroll-top" href="#top" data-scroll>
        <span class="btn-scroll-top-tooltip text-muted font-size-sm mr-2">Top</span><i
            class="btn-scroll-top-icon czi-arrow-up"> </i>
    </a>

    <!-- Vendor scrits: js libraries and plugins-->
    {{-- <script src="{{asset('assets/front-end')}}/vendor/jquery/dist/jquery.slim.min.js"></script> --}}
    <script src="{{ asset('assets/front-end') }}/vendor/jquery/dist/jquery-2.2.4.min.js"></script>
    <script src="{{ asset('assets/front-end') }}/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    {{-- Toastr --}}
    <script src={{ asset('assets/back-end/js/toastr.js') }}></script>
    <!-- Main theme script-->
    <script src="{{ asset('assets/front-end') }}/js/theme.min.js"></script>
    <script src="{{ asset('assets/front-end') }}/js/slick.min.js"></script>

    <script src="{{ asset('assets/front-end') }}/js/sweet_alert.js"></script>
    {{-- Toastr --}}
    <script src={{ asset('assets/back-end/js/toastr.js') }}></script>
    {!! Toastr::message() !!}

    {{-- @if ($errors->any())
    <script>
        @foreach ($errors->all() as $error)
        toastr.error('{{$error}}', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        @endforeach
    </script>
@endif --}}

    <script>
        function currency_select(val) {
            if (val === 'multi_currency') {
                toastr.warning(
                    "Multi-currency is depends on exchange rate and your gateway configuration, So if you don't need multi-currency it will be better select single currency. (We prefer to use single currency).", {
                        CloseButton: true,
                        ProgressBar: true
                    });
            }
        }
    </script>
</body>

</html>
